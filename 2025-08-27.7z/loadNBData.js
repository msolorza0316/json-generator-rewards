// loadNBData.js
function loadNBData() {
    const nbData = {
        productName: document.querySelector("#nb-data #productName")?.textContent.trim() || "",
        redirectUrl: document.querySelector("#nb-data #redirectURL")?.textContent.trim() || "",
        providerId: document.querySelector("#nb-data #nb-providerID")?.textContent.trim() || ""
    };

    if (!window.template || !window.redrawForm) {
        showToast("Form not ready yet!");
        return;
    }

    // Ensure form is drawn
    redrawForm();

    // Wait until inputs exist
    const waitForInputs = setInterval(() => {
        const productInput = document.querySelector('input[data-field-id="banner.productName"]');
        const redirectInput = document.querySelector('input[data-field-id="banner.redirectUrl"]');
        const providerInput = document.querySelector('input[data-field-id="banner.providerId"]');

        if (productInput && redirectInput && providerInput) {
            clearInterval(waitForInputs);

            // Fill inputs
            productInput.value = nbData.productName;
            redirectInput.value = nbData.redirectUrl;
            providerInput.value = nbData.providerId;

            // Trigger input events
            [productInput, redirectInput, providerInput].forEach(input => {
                input.dispatchEvent(new Event('input', { bubbles: true }));
            });

            // Update template
            window.template.banner.productName = nbData.productName;
            window.template.banner.redirectUrl = nbData.redirectUrl;
            window.template.banner.providerId = nbData.providerId;

            // Update JSON output
            const updatedJSON = buildTemplateFromForm();
            showOutputJSON(updatedJSON);
            showToast("NB data loaded successfully!");
        }
    }, 50);
}

// Hook button
document.addEventListener('DOMContentLoaded', () => {
    const btn = document.getElementById("load-nb-data");
    if (btn) btn.addEventListener("click", loadNBData);
});
