// storage.js - fully integrated and safe NB loader
document.addEventListener('DOMContentLoaded', async () => {

    // --- Build template from form inputs ---
    function buildTemplateFromForm() {
        const updatedJSON = JSON.parse(JSON.stringify(template));
        const mainTitleInput = document.querySelector("input[data-field-id='banner.title']");
        const mainTitleValue = mainTitleInput?.value || template.banner.title;

        function updateTitles(obj) {
            for (let key in obj) {
                if (key === "title" && obj !== updatedJSON.modal.members.redirectStep) obj[key] = mainTitleValue;
                else if (typeof obj[key] === "object") updateTitles(obj[key]);
            }
        }
        updateTitles(updatedJSON);

        document.querySelectorAll("[data-field-id]").forEach(inp => {
            valueMap.forEach(data => {
                if (data.id === inp.dataset.fieldId) {
                    data.paths.forEach(path => {
                        let ref = updatedJSON;
                        for (let i = 0; i < path.length - 1; i++) ref = ref[path[i]];
                        if (!ref[path[path.length - 1]] || inp.value !== "") ref[path[path.length - 1]] = inp.value;
                    });
                }
            });
        });

        return updatedJSON;
    }

    function showOutputJSON(obj) {
        const outputEl = document.getElementById("output");
        outputEl.textContent = JSON.stringify(obj, null, 4);
        document.getElementById("outputContainer").style.display = "block";
    }

    // --- Bind all buttons ---
    function bindButtons() {
        // Generate JSON
        document.getElementById("generateBtn")?.addEventListener("click", () => {
            showOutputJSON(buildTemplateFromForm());
            showToast("JSON generated!");
        });

        // Copy JSON
        document.getElementById("copyBtn")?.addEventListener("click", () => {
            const outputEl = document.getElementById("output");
            if (!outputEl?.textContent) return;
            navigator.clipboard.writeText(outputEl.textContent)
                .then(() => showToast("Copied to clipboard!"))
                .catch(() => alert("Copy failed!"));
        });

        // Save locally
        document.getElementById("saveLocalBtn")?.addEventListener("click", () => {
            const currentData = buildTemplateFromForm();
            localStorage.setItem("savedJSON", JSON.stringify(currentData));
            showToast("Saved locally!");
            showOutputJSON(currentData);
        });

        // Load saved
        document.getElementById("loadLocalBtn")?.addEventListener("click", () => {
            const saved = localStorage.getItem("savedJSON");
            if (!saved) { showToast("No saved data found."); return; }
            try {
                Object.assign(template, JSON.parse(saved));
                redrawForm();
                showOutputJSON(template);
                showToast("Loaded saved data!");
            } catch (err) {
                console.error(err);
                alert("Failed to load saved data.");
            }
        });

        // Clear form
        document.getElementById("clearFormBtn")?.addEventListener("click", () => {
            localStorage.removeItem("savedJSON");
            loadTemplate('template.json').then(() => {
                redrawForm();
                document.getElementById("outputContainer").style.display = "none";
                document.getElementById("output").textContent = "";
                showToast("Form reverted to original template!");
            });
        });
    }

    // --- Safe NB Data loader ---
    function bindNBLoader() {
        const loadNBBtn = document.getElementById("load-nb-data");
        if (!loadNBBtn) return;

        loadNBBtn.addEventListener("click", () => {
            const nbData = {
                productName: document.querySelector("#nb-data #productName")?.textContent.trim() || "",
                redirectUrl: document.querySelector("#nb-data #redirectURL")?.textContent.trim() || "",
                providerId: document.querySelector("#nb-data #nb-providerID")?.textContent.trim() || ""
            };

            // Wait for inputs to exist
            const inputs = [
                'input[data-field-id="banner.productName"]',
                'input[data-field-id="banner.redirectUrl"]',
                'input[data-field-id="banner.providerId"]'
            ];

            let checkCount = 0;
            const maxChecks = 50; // 50 * 50ms = 2.5s max wait
            const interval = setInterval(() => {
                const elems = inputs.map(sel => document.querySelector(sel));
                if (elems.every(el => el)) {
                    clearInterval(interval);
                    const [productInput, redirectInput, providerInput] = elems;

                    // Fill inputs
                    productInput.value = nbData.productName;
                    redirectInput.value = nbData.redirectUrl;
                    providerInput.value = nbData.providerId;

                    // Trigger input events
                    elems.forEach(input => input.dispatchEvent(new Event('input', { bubbles: true })));

                    // Update template
                    template.banner.productName = nbData.productName;
                    template.banner.redirectUrl = nbData.redirectUrl;
                    template.banner.providerId = nbData.providerId;

                    showOutputJSON(buildTemplateFromForm());
                    showToast("NB data loaded successfully!");
                } else {
                    checkCount++;
                    if (checkCount > maxChecks) {
                        clearInterval(interval);
                        showToast("Form inputs not ready yet!");
                    }
                }
            }, 50);
        });
    }

    // --- Load template and render form once ---
    await loadTemplate('template.json');
    redrawForm();

    // Wait a bit to ensure DOM is ready, then bind buttons
    setTimeout(() => {
        bindButtons();
        bindNBLoader();
    }, 100); // 100ms delay should guarantee inputs exist
});
